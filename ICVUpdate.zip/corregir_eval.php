<?php
/**
 * Script de corrección automática para eval.json
 * Intercambia los valores de "cuenta" y "nocuenta" que están invertidos
 * Se ejecuta una sola vez y luego se elimina automáticamente
 */

// CONFIGURACIÓN DE ZONA HORARIA
date_default_timezone_set('America/Mexico_City');

// Archivo a corregir
$evalFile = '../ICV/eval.json';

// Verificar que el archivo existe
if (!file_exists($evalFile)) {
    exit(1);
}

try {
    // Leer el archivo JSON
    $jsonContent = file_get_contents($evalFile);
    if ($jsonContent === false) {
        throw new Exception("No se pudo leer el archivo eval.json");
    }
    
    $data = json_decode($jsonContent, true);
    if ($data === null) {
        throw new Exception("Error al decodificar JSON");
    }
    
    $correcciones = 0;
    
    // Recorrer todos los elementos y corregir los valores invertidos
    foreach ($data as $tag => $evaluaciones) {
        foreach ($evaluaciones as $timestamp => $evaluacion) {
            if (isset($evaluacion['cuenta']) && isset($evaluacion['nocuenta'])) {
                // Solo corregir si al menos uno de los valores es true (hay evaluación real)
                if ($evaluacion['cuenta'] || $evaluacion['nocuenta']) {
                    // Intercambiar los valores
                    $tempCuenta = $evaluacion['cuenta'];
                    $data[$tag][$timestamp]['cuenta'] = $evaluacion['nocuenta'];
                    $data[$tag][$timestamp]['nocuenta'] = $tempCuenta;
                    $correcciones++;
                }
            }
        }
    }
    
    // Guardar el archivo corregido
    $jsonCorregido = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($jsonCorregido === false) {
        throw new Exception("Error al codificar JSON");
    }
    
    if (file_put_contents($evalFile, $jsonCorregido) === false) {
        throw new Exception("No se pudo escribir el archivo corregido");
    }
    
    // Auto-eliminación del script después de ejecutarse
    $scriptPath = __FILE__;
    if (function_exists('register_shutdown_function')) {
        register_shutdown_function(function() use ($scriptPath) {
            if (file_exists($scriptPath)) {
                unlink($scriptPath);
            }
        });
    }
    
} catch (Exception $e) {
    error_log("ICV Error: " . $e->getMessage());
    exit(1);
}
?> 