<?php
/**
 * Script de limpieza para eliminar archivos de control
 * Se ejecuta automáticamente para mantener el sistema limpio
 */

$controlFile = '../ICV/eval_corregido.flag';

// Si existe el archivo de control, verificar si tiene más de 24 horas
if (file_exists($controlFile)) {
    $fileTime = filemtime($controlFile);
    $currentTime = time();
    $hoursDiff = ($currentTime - $fileTime) / 3600;
    
    // Si han pasado más de 24 horas, eliminar el archivo de control
    if ($hoursDiff > 24) {
        unlink($controlFile);
    }
}

// Auto-eliminación del script después de ejecutarse
$scriptPath = __FILE__;
if (function_exists('register_shutdown_function')) {
    register_shutdown_function(function() use ($scriptPath) {
        if (file_exists($scriptPath)) {
            unlink($scriptPath);
        }
    });
}
?> 